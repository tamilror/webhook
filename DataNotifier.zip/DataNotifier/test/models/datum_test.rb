require "test_helper"

class DatumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
